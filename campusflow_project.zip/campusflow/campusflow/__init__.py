"""CampusFlow ticket management package."""
